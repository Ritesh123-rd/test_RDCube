package com.example.demo;

import java.util.List;

public interface buyerService {

	void fada(buyerreg bbobj);

	buyerreg check_login_user(String email, String password);

	List<buyerreg> display();

	buyerreg getonebuyer(int id);

	void deletedata(int id);

}
