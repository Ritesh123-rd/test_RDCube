package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class adDao implements adService {

	@Autowired
	adRepo adRepo;

	@Override
	public admin save_data_admin(admin admin) {
		admin ads1=adRepo.save(admin);
		return ads1;
	}
	
}
