package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class proDao implements proService
{

	@Autowired
	proRepo pr;
	@Override
	public void upload(com.example.demo.upload p) {
		// TODO Auto-generated method stub
		pr.save(p);
	}
	@Override
	public List<upload> getdisplay() {
		// TODO Auto-generated method stub
		return pr.findAll();
	}
	@Override
	public List<com.example.demo.upload> dataupload() {
		
		return pr.findAll();
	}
	@Override
	public com.example.demo.upload gettodata(int id) {
		upload ddUpload=pr.getById(id);
		return ddUpload;
	}
	@Override
	public void deletegetdata(int id) {
		pr.deleteById(id);
		
	}
	@Override
	public com.example.demo.upload getonedata1(int id) {
		upload upload= pr.getById(id);
		return upload;
	}
	
	@Override
	public List<upload> search(String city) {
		
		return pr.findByCity(city);
	}
	
	
	
}
