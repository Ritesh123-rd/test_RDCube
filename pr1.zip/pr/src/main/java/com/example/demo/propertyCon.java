package com.example.demo;


import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.taglibs.standard.lang.jstl.test.beans.PublicBean1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import net.bytebuddy.asm.Advice.OffsetMapping.ForOrigin.Renderer.ForReturnTypeName;


@Controller
public class propertyCon {

	@Autowired
	selService sobj;

	@Autowired
	buyerService bobj;

	@Autowired
	ownerService osobj;

	@Autowired
	adService adService;

	@Autowired
	feedService feedService;

	@Autowired
	messageService msgService;

	@RequestMapping("/")
	public String get() {
		return "dashbord";
	}

	@RequestMapping("/register")
	public String set() {
		return "sellerRegi";

	}

	@PostMapping("/reg")
	public String seller(@ModelAttribute("seObj") sellerreg seObj) {
		sobj.hada(seObj);
		return "sellogin";

	}

	@PostMapping("login_check")
	public String lio(@ModelAttribute("seObj") sellerreg seObj, HttpSession s1) {
		sellerreg s2 = new sellerreg();
		String email = seObj.getEmail();
		String password = seObj.getPassword();

		Object logi = sobj.check_valid_user(email, password);

		if (Objects.nonNull(logi)) {
			// System.out.println(email);
			s1.setAttribute("email", password);
			return "dashbord";

		} else if (email.equals("Admin@gmail.com") && password.equals("Admin@123")) {
			return "dashbord";
		} else {
			return "redirect:/sellogin";
		}
	}

	@RequestMapping("/dashbord")
	public String dash(HttpServletRequest reg) {
		HttpSession ss = reg.getSession(false);
		String email = (String) ss.getAttribute("email");
		if (email != null || ss.getAttribute(email) == null) {
			return "redirect:/sellogin";
		} else {
			return "dashbord";
		}
	}

	@RequestMapping("/sellogin")
	public String da() {
		return "sellogin";
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest reg, HttpSession sa, HttpSession sp, HttpSession sr) {
		if (sa.getAttribute("email") != null) {
			sa.removeAttribute("email");
			sa.invalidate();
			return "redirect:/";
		}
		if (sp.getAttribute("buyer") != null) {
			sp.removeAttribute("buyer");
			sp.invalidate();
			return "redirect:/";
		}
		if (sr.getAttribute("owner") != null) {
			sr.removeAttribute("owner");
			sr.invalidate();
			return "redirect:/";

		}
		return "redirect:/";
	}

	/*------========== mapping home page=================== --------*/
	@RequestMapping("/about1")
	public String about1(HttpServletRequest reg, HttpSession session, HttpSession sp, HttpSession sr) {

		return "about";

	}

	@RequestMapping("/index1")
	public String About122( @ModelAttribute("data")upload data,ModelMap m, HttpServletRequest reg, HttpSession session, HttpSession sp, HttpSession sr) {
		List<upload> sgList=ps.dataupload();
		m.addAttribute("sgList", sgList);
		return "dashbord";

	}

	@RequestMapping("/property-grid1")
	public String property(@ModelAttribute("data")upload data ,HttpServletRequest reg, HttpSession session,ModelMap m) {

	List<upload> sgList= ps.getdisplay();
	m.addAttribute("sgList", sgList);
		
		return "property-grid";
	}

	
	@RequestMapping("/property-single1")
	public String pages(@RequestParam("id")int id,ModelMap map,HttpServletRequest reg, HttpSession session) {

		upload updUpload=ps.getonedata1(id);
		map.addAttribute("updUpload", updUpload);
		
		return "property-single";

	}

	@RequestMapping("/contact1")
	public String contact(HttpServletRequest reg, HttpSession session) {

		return "contact";

	}

	// Buyer registration strat and login start

	@RequestMapping("/register1")
	public String BuyerRegi() {
		return "buyerRegi";

	}

	@PostMapping("/buyer_reg")
	public String Buyersave(@ModelAttribute("bbobj") buyerreg bbobj) {
		bobj.fada(bbobj);
		return "buyerlog";
	}

	@RequestMapping("/buyer_login_check")
	public String Buyer_Login() {
		return "buyerlog";
	}

	@PostMapping("/buyer_login_check")
	public String Buyer_login_check1(@ModelAttribute("beobj") buyerreg beobj, HttpSession Hs1) {
		buyerreg br1 = new buyerreg();
		String Email = beobj.getEmail();
		String Password = beobj.getPassword();
		buyerreg logi1 = bobj.check_login_user(Email, Password);

		if (Objects.nonNull(logi1)) {
			// System.out.println(email);
			Hs1.setAttribute("email", Email);
			return "dashbord";
		} else {
			return "redirect:/buyerlog";
		}
	}

	@PostMapping("/dashbord")
	public String buyer_log_user(HttpServletRequest reg)

	{
		HttpSession dd = reg.getSession(false);
		String buyer = (String) dd.getAttribute("buyer");
		if (buyer != null || dd.getAttribute(buyer) == null) {
			return "redirect:/buyerlog";
		} else {
			return "dashbord";
		}
	}

	@RequestMapping("/buyerlog")
	public String buyer_dashbord() {
		return "buyerlog";

	}

	/*
	 * ------=======owner registration and login session start fechting
	 * data===========------
	 */

	@RequestMapping("/register3")
	public String owner_regi_check() {
		return "ownerRegi";

	}

	@PostMapping("/owner_reg")
	public String ownersave(@ModelAttribute("obj") owenrreg obj) {
		osobj.rara(obj);
		return "ownerlog";
	}

	@RequestMapping("/owner_login_check")
	public String owner_check() {
		return "ownerlog";

	}

	@PostMapping("/owner_login_check")
	public String login_check_set(@ModelAttribute("odobj") owenrreg odobj, HttpSession hs3) {
		owenrreg AA = new owenrreg();
		String email = odobj.getEmail();
		String Password = odobj.getPassword();

		owenrreg logi4 = osobj.check_login_data(email, Password);
		hs3.setAttribute("email", email);
		if (Objects.nonNull(logi4)) {

			return "dashbord";

		} else {
			return "redirect:/ownerlog";
		}
	}

	@PostMapping("/ownerdash")
	public String login_check_own(HttpServletRequest reg)

	{
		HttpSession ff = reg.getSession();
		String email = (String) ff.getAttribute("email");
		if (email != null || ff.getAttribute(email) == null) {
			return "redirect:/ownerlog";

		} else {
			return "dashbord";
		}
	}

	@RequestMapping("/ownerlog")
	public String owner_dr() {
		return "ownerlog";

	}

	@RequestMapping("/registration_page")
	public String hii() {
		return "welcome";

	}

	/*
	 * ====================admin dashbord all database and project
	 * login============================
	 */

	@RequestMapping("/admin")
	public String admin() {
		return "admin";

	}

	@PostMapping("admin_login")
	public String admindashboard(@RequestParam("email") String email, @RequestParam("password") String password) {
		if (email.equals("admin@gmail.com") && password.equals("admin@123")) {

			return "admindashboard";
		}
		return "admin";
	}

	@RequestMapping("/admindashboard")
	public String admin1() {
		return "admindashboard";

	}

	/*
	 * ==================buyer table display and edit and delete ==================
	 */
	@RequestMapping("buyer_data")
	public String buyerdata(ModelMap m) {
		List<buyerreg> sp = bobj.display();
		m.addAttribute("sp", sp);
		return "buyer_data";

	}

	@RequestMapping("/buyer_edit")
	public String buyer_edit(@RequestParam("id") int id, ModelMap m) {
		buyerreg dataBuyerreg = bobj.getonebuyer(id);
		m.addAttribute("dataBuyerreg", dataBuyerreg);
		return "buyer_edit";

	}

	@PostMapping("/editb")
	public String edit(@ModelAttribute("bb") buyerreg bb) {
		bobj.fada(bb);
		return "redirect:/buyer_data";

	}

	@RequestMapping("/buyer_delete")
	public String deleteb(@RequestParam("id") int id) {
		bobj.deletedata(id);
		return "redirect:/buyer_data";

	}
	/* ================owner table display and edit and delete ================== */

	@RequestMapping("owner_data")
	public String ownerdata(ModelMap m) {
		List<owenrreg> sp = osobj.display();
		m.addAttribute("sp", sp);
		return "owner_data";

	}

	@RequestMapping("/owner_edit")
	public String owner_edit(@RequestParam("id") int id, ModelMap m) {
		owenrreg dataOwenrreg = osobj.getonedata(id);
		m.addAttribute("dataOwenrreg", dataOwenrreg);

		return "owner_edit";

	}

	@PostMapping("/editowner")
	public String editowner1(@ModelAttribute("obj") owenrreg obj) {
		osobj.rara(obj);
		return "redirect:/owner_data";

	}

	@RequestMapping("/owner_delete")
	public String deletOwner(@RequestParam("id") int id) {
		osobj.deleteowner(id);
		return "redirect:/owner_data";
	}

	/*
	 * ================seller display table and edit and delete===================
	 */

	@RequestMapping("seller_data")
	public String sellerdata(ModelMap m) {
		List<sellerreg> sp = sobj.display();
		m.addAttribute("sp", sp);
		return "seller_data";

	}

	@RequestMapping("/seller_edit")
	public String seller_editi(@RequestParam("id") int id, ModelMap m) {
		sellerreg dataseSellerreg = sobj.getonedata(id);
		m.addAttribute("dataseSellerreg", dataseSellerreg);
		return "seller_edit";

	}

	@PostMapping("/editseller")
	public String editseller2(@ModelAttribute("seObj") sellerreg seObj) {
		sobj.hada(seObj);
		return "redirect:/seller_data";

	}

	@RequestMapping("/seller_delete")
	public String deletseller(@RequestParam("id") int id) {
		sobj.deleteseller(id);
		return "redirect:/seller_data";
	}

	/* =================feedback mapping============= */
	@RequestMapping("feedback")
	public String feed1() {
		return "contact";

	}

	@RequestMapping("/feedback_data")
	public String feed(@ModelAttribute("fee") feedback fee) {
		feedService.gd(fee);
		return "contact";

	}

	@RequestMapping("/feedback_con")
	public String feedContact(ModelMap m) {
		List<feedback> sp = feedService.display();
		m.addAttribute("sp", sp);
		return "feedback_con";

	}

	@RequestMapping("/feedback_delete")
	public String deletefeedback(@RequestParam("id") int id) {
		feedService.deletefeedback22(id);
		return "redirect:/feedback_con";

	}
	/* ======= Comment session and blog start update and insert data======== */
	
	@RequestMapping("ownermessage")
	public String meg()
	{
		return "property-single";
		
	}
	@RequestMapping("/ownermessage12")
	public String msg1(@ModelAttribute("mm") ownermessage mm)
	{
		msgService.adddata(mm);
		//System.out.println(mm);
		return "property-single" ;
		
	}
	@RequestMapping("/msgtable")
	public String feedC(ModelMap m) {
		List<ownermessage> sp =msgService .display();
		m.addAttribute("sp", sp);
		return "msgtable";

	}
	@RequestMapping("/msg_edit")
	public String msgedit()
	{
		return "msg_edit";
		
	}
	

	/*
	 * ============== add_property mapping add list,delete update all
	 * opration=================*/
	
	@Autowired
	proService ps;
	
	@RequestMapping("/propdetails")
	public String adda()
	{
		return "propdetails";
		
	}
	@PostMapping("/next")
	public String uplaod(@RequestParam("file") MultipartFile file,@ModelAttribute("p") upload p) {
		
		try {
			String filename=file.getOriginalFilename();
			String path = "C:\\Users\\ganes\\eclipse-workspace\\pr\\src\\main\\resources\\static\\Assests\\img";
			byte []filedata=file.getBytes();
			
			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path + "/" + filename));
			bout.write(filedata);
			bout.flush();
			bout.close();
			//System.out.println(filename);
			p.setName(filename);
			ps.upload(p);
			return "redirect:/property-grid1";
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "Error uploading file: " + e.getMessage();
		}
		
	}
	@RequestMapping("/propertydetails2")
	public String datapass(ModelMap m)
	{
		List<upload> propertyd =ps.dataupload();
		m.addAttribute("propertyd", propertyd);
		return "propertydetails2";
		
	}
	@RequestMapping("/propertyd_edit")
	public String peropediti(@RequestParam("id") int id, ModelMap m) {
		upload datauopload= ps.gettodata(id);
		m.addAttribute("datauopload", datauopload);
		return "propertyd_edit";

	}
	
	@PostMapping("/propertyeditooo")
	public String propertyhooo(@ModelAttribute("p") upload p) {
		ps.upload(p);
		return "redirect:/propertydetails2";
	
	}
	@RequestMapping("/property_delete")
	public String deleteproperty(@RequestParam ("id") int id)
	{
		ps.deletegetdata(id);
		return "redirect:/propertydetails2";
		
	}
	@PostMapping("/searchvalid")
	public String search(@RequestParam(required = false)String city,ModelMap model)
	{
		List<upload> seaList=ps.search(city);
		model.addAttribute("sgList", seaList);
		
		return "property-grid";
		
	}
	@RequestMapping("/propertysearch")
	public String sea( )
	{
		return "propertysearch";
	
	}
	
	
}


