package com.example.demo;

public interface adService {

	admin save_data_admin(admin admin);

	
	
	

}
