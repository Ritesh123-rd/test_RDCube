package com.example.demo;

import java.util.List;

public interface messageService {

	void adddata(ownermessage mm);

	List<ownermessage> display();

	ownermessage getom(int id);

}
