package com.example.demo;

import java.util.List;

public interface selService {

	void hada(sellerreg seObj);

	Object check_valid_user(String email, String password);

	List<sellerreg> display();

	sellerreg getonedata(int id);

	void deleteseller(int id);


}
