package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class upload {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	String fullname;
	
	String name;
	String address;
	String city;
	String location;
	String area;
	String beds;
	String baths;
	String garage;
	String price;
	String description;
	String amenities;
	
	
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAmenities() {
		return amenities;
	}
	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getBeds() {
		return beds;
	}
	public void setBeds(String beds) {
		this.beds = beds;
	}
	public String getBaths() {
		return baths;
	}
	public void setBaths(String baths) {
		this.baths = baths;
	}
	public String getGarage() {
		return garage;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public void setGarage(String garage) {
		this.garage = garage;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "upload [id=" + id + ", fullname=" + fullname + ", name=" + name + ", address=" + address + ", city="
				+ city + ", location=" + location + ", area=" + area + ", beds=" + beds + ", baths=" + baths
				+ ", garage=" + garage + ", price=" + price + ", description=" + description + ", amenities="
				+ amenities + "]";
	}
	

	
}
