package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class owenrreg {

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String Oname;
	private String Lname;
	private String phonenumber;
	private String email;
	private String password;
	private String address;
	private String gender;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOname() {
		return Oname;
	}
	public void setOname(String oname) {
		this.Oname = oname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		this.Lname = lname;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "owenrreg [id=" + id + ", Oname=" + Oname + ", Lname=" + Lname + ", phonenumber=" + phonenumber
				+ ", email=" + email + ", password=" + password + ", address=" + address + ", gender=" + gender + "]";
	}
	
	
}
