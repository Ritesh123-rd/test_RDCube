package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class feedDao implements feedService
{
	@Autowired
	feedRepo fr;

	@Override
	public void gd(feedback fee) {
		fr.save(fee);
		
	}

	@Override
	public List<feedback> display() {
		return fr.findAll();		
	}

	@Override
	public void deletefeedback22(int id) {
		fr.deleteById(id);
		
	}
	

}
