package com.example.demo;

import java.util.List;

public interface proService {

	void upload(upload p);

	List<upload> getdisplay();

	List<com.example.demo.upload> dataupload();

	com.example.demo.upload gettodata(int id);

	void deletegetdata(int id);

	

	com.example.demo.upload getonedata1(int id);

	List<com.example.demo.upload> search(String city);

	

	

}
