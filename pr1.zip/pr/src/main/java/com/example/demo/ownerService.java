package com.example.demo;

import java.util.List;

public interface ownerService {

	void rara(owenrreg obj);

	owenrreg check_login_data(String email, String password);

	List<owenrreg> display();

	owenrreg getonedata(int id);

	void deleteowner(int id);

	
	

}
