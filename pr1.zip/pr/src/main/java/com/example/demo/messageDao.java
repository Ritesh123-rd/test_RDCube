package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class messageDao implements messageService
{
	@Autowired
	messageRepo mRepo;
	

	@Override
	public void adddata(ownermessage mm) {
		
		mRepo.save(mm);
	}


	@Override
	public List<ownermessage> display() {
		
		return mRepo.findAll();
	}


	@Override
	public ownermessage getom(int id) {
		ownermessage om=mRepo.getById(id);
		return null;
	}

}
