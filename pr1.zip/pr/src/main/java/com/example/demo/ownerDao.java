package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ownerDao implements ownerService 
{
	@Autowired
	ownerRepo oRobj;

	@Override
	public void rara(owenrreg obj) {
		oRobj.save(obj);
		
	}

	@Override
	public owenrreg check_login_data(String email, String password) {
		owenrreg pw=oRobj.findByEmailAndPassword(email,password);
		return pw;
	}

	@Override
	public List<owenrreg> display() {
		
		return oRobj.findAll() ;
	}

	@Override
	public owenrreg getonedata(int id) {
		owenrreg spO =oRobj.getById(id);
		return spO;
	}

	@Override
	public void deleteowner(int id) {
		 oRobj.deleteById(id);
		
	}

	

}
