package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class selDao implements selService
{
	@Autowired
	selRepo sr;
	

	@Override
	public void hada(sellerreg seObj) {
		sr.save(seObj);
		
	}


	@Override
	public Object check_valid_user(String email, String password) {
		Object px=sr.findByEmailAndPassword(email,password);
		return px;
	}


	@Override
	public List<sellerreg> display() {
		return sr.findAll();		
	}


	@Override
	public sellerreg getonedata(int id) {
		sellerreg sellerreg= sr.getById(id);
		return sellerreg;
	}


	@Override
	public void deleteseller(int id) {
		sr.deleteById(id);
		
	}



}
