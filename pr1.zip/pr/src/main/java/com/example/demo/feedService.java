package com.example.demo;

import java.util.List;

public interface feedService {

	void gd(feedback fee);

	List<feedback> display();

	void deletefeedback22(int id);

}
