package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class buyerDao implements buyerService
{
	@Autowired
	buyerRepo bd;

	@Override
	public void fada(buyerreg bbobj) {
		bd.save(bbobj);
	}

	@Override
	public buyerreg check_login_user(String email, String password) {
		buyerreg pz=bd.findByEmailAndPassword(email,password);
		return pz ;
	}

	@Override
	public List<buyerreg> display() {
		return bd.findAll();		 
	}

	@Override
	public buyerreg getonebuyer(int id) {
		buyerreg sp=bd.getById(id);
		
		return sp;
	}

	@Override
	public void deletedata(int id) {
	bd.deleteById(id);
		
	}

	
	

}
